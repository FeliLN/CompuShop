import React from 'react'; 
import './App.css';
import { NavBar } from './Components/NavBar/NavBar';
import { HashRouter as Router,Route, Switch } from 'react-router-dom';
import Home from './Components/Home/Home';
import Shop from './Components/Shop/Shop';

  

function App() {

  
  return (
    <div className="App">
      <section className="App-content">
     
      <Router>
        < NavBar /> 
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/shop" component={Shop} />
          
          </Switch>

       
      </Router>
      </section>
    </div>
  );
}

export default App;
