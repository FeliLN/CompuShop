import React from 'react'
import Carta from '../Carta/Carta';

const Shop = (props) => {
    return (
        <div>
            <Carta />
        </div>
    )
}

export default Shop
