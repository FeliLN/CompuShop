import React from 'react'



const Home = () => {


    return (
        <div>
            <h1>
         Compu Mundo Hiper Mega Red
        </h1>

        </div>
    )
}

export default Home



